const express = require("express");
const mongoose = require("mongoose");
const app = express();
app.use(express.static(__dirname));
app.use(express.json());

mongoose.connect("mongodb://127.0.0.1:27017/Student");
const conn = mongoose.connection;

conn.on("connected", () => {
  console.log("connected");
});

const studentSchema = mongoose.Schema({
  id: String,
  name: String,
  age: String,
  email: String,
  course: String,
});

const stud_data = mongoose.model("stud_data", studentSchema, "student_info");

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/index.html");
});

app.get("/api/get-student-details", (req, res) => {
  stud_data.find().then((data) => {
    res.json(data);
  });
});

app.post("/api/addNewStudent", (req, res) => {
  stud_data
    .create({
      id: req.body.id,
      name: req.body.name,
      age: req.body.age,
      email: req.body.email,
      course: req.body.course,
    })
    .then((newStudent) => {
      res.json(newStudent);
    });
});

app.put("/api/updateStudent/:id", (req, res) => {
  const studId = req.params.id;
  const updateData = {
    name: req.body.name,
    age: req.body.age,
    email: req.body.email,
    course: req.body.course,
  };
  stud_data
    .findOneAndUpdate({ id: studId }, updateData, { new: true })
    .then((err, data) => {
      res.json(data);
    });
});

app.delete("/api/deleteStudent/:id", (req, res) => {
  const studId = req.params.id;
  stud_data.deleteOne({ id: studId }).then((err, data) => {
    res.json(data);
  });
});

app.listen(3000, function () {
  console.log("Server is running on http://localhost:3000/");
});
