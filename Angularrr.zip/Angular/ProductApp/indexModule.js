var module = angular.module("myApp", []);
module.controller("myAppController", function ($scope, $http) {
  $scope.prodList = [];
  $scope.newProd = {};

  $scope.getProdData = function () {
    $http.get("/api/getProductData").then((response) => {
      $scope.prodList = response.data;
    });
  };

  $scope.postProdData = function () {
    $http.post("/api/postProductData", $scope.newProd).then((response) => {
      $scope.prodList = response.data;
    });
  };

  $scope.getProdData();
});
