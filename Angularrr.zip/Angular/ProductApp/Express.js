const express = require("express");
const mongoose = require("mongoose");
const app = express();

app.use(express.json());
app.use(express.static(__dirname));

// Connection
mongoose.connect("mongodb://127.0.0.1:27017/Product");
const conn = mongoose.connection;
conn.on("connected", () => {
  console.log("MongoDb Connected");
});

const prodSchema = mongoose.Schema({
  ProdID: String,
  ProdName: String,
  Price: String,
  date: Date,
  image: String,
});

const prodModel = mongoose.model("prodModel", prodSchema, "product_info");

app.get("/api/getProductData", (request, response) => {
  prodModel.find().then((result) => {
    response.json(result);
  });
});

app.post("/api/postProductData", (request, response) => {
  var prod = new prodModel(request.body);
  prod.save().then(() => {
    prodModel.find().then((result) => {
      response.json(result);
    });
  });
});

app.get("/", (request, response) => {
  response.sendFile(__dirname + "/index.html");
});

app.listen(1209, () => {
  console.log("Server Started");
});
