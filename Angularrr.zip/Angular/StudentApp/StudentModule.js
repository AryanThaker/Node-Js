var app = angular.module("myApp", []);

app.controller("myAppController", function ($scope, $http) {
  $scope.students = [];
  $scope.newStudent = {};

  $scope.students_data = function () {
    $http.get("/api/get-student-details").then(function (response) {
      $scope.students = response.data;
    });
  };

  $scope.students_data();

  $scope.addStudent = function () {
    $http
      .post("/api/addNewStudent", $scope.newStudent)
      .then(function (response) {
        $scope.students.push(response.data);
        $scope.newStudent = {};
      });
  };

  $scope.students_data();

  $scope.updateStudent = function (stud) {
    stud.editing = true;
  };

  $scope.saveStudent = function (stud) {
    const updateData = {
      name: stud.name,
      age: stud.age,
      email: stud.email,
      course: stud.course,
    };
    $http
      .put("/api/updateStudent/" + stud.id, updateData)
      .then(function (response) {
        $scope.students.push(response.data);
        stud.editing = false;
        $scope.students_data();
      });
  };

  $scope.deleteStudent = function (stud) {
    $http.delete("/api/deleteStudent/" + stud.id).then(function (response) {
      $scope.students = response.data;
      $scope.students_data();
    });
  };
});
